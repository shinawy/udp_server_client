#include "message.h"
using namespace std;


int main () {
    Message m1 (0,"MENON", 5, 0);
    cout << m1.marshal() << endl;
    

}